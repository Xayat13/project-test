<?php 
	session_start();
	require('../models/smodel.php');
	
	if(isset($_REQUEST['submit']))
	{
		
		$name = $_REQUEST['name'];
		$email = $_REQUEST['email'];
		$username = $_REQUEST['usern'];
		$password = $_REQUEST['password'];
		$conPass = $_REQUEST['confirmPass'];
		$gender  =$_REQUEST ['gender'];
		$date=  $_REQUEST ['date'];

		if ($_FILES['pic']['size'] == 0) 
		{
			echo "Profile picture is not selected.". "<br>";
		}else
		{
			$src = $_FILES['pic']['tmp_name'];
			$des = "../assets/".$_FILES['pic']['name'];
			move_uploaded_file($src, $des);
		}

		$accType =$_REQUEST ['accType'];





		if($conPass == $password )
		{
			$status = s_reg($name,$email,$username, $password , $gender, $date, $accType,$_FILES['pic']['name']);
			if($status)
			{
				echo "Sucessfull reg";
			}
			else 
			{
				echo "Error reg";	
			}
			

		}
	
			
		
		

		
	}
	?>