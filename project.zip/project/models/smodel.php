<?php 

function getConnection()
{
	$host = "localhost";
	$dbname= "final_project";
	$dbuser = "root";
	$dbpass = "";

	$con = mysqli_connect($host, $dbuser, $dbpass, $dbname);
	return $con;
}

	function login($username, $password)
	{
		$con = getConnection();

		$sql = "select * from users where username='{$username}' and password='{$password}'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result))
        {
			return true;
		}else
        {
			return false;
		}
	}

	function s_reg($name,$email,$username, $password , $gender, $date, $accType, $pic)
    {
		$con = getConnection();
		$sql = "insert into users values ('{$name}', '{$username}','{$email}', '{$password}', '{$gender}', '{$date}', '{$accType}','{$pic}','Active')";

		if(mysqli_query($con, $sql))
        {
			return true;
		}else
        {
			return false;
		}
	}


	function userInfo($username) 
	{
		$con = getConnection();
		$sql = "select * from users where username = '{$username}'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}


	//Car aadd


	

	function register($name, $seller, $price, $picture, $status) 
	{
		$con = getConnection('localhost', 'root', '', 'final_project');
		$sql = "insert into newcars values('{$name}','{$seller}','{$price}','{$picture}',{$status}')";

		if (mysqli_query($con, $sql)) {
			return true;
		} else {
			return false;
		}
	}
	
	function deleteCar($id) {
		$con = getConnection('localhost', 'root', '', 'final_project');
		$sql = "delete from newcars where id = '{$id}'";

		if (mysqli_query($con, $sql)) {
			return true;
		}else {
			return false;
		}
	}
	function  addCar($name,$price,$pic) 
	{
		$con = getConnection('localhost', 'root', '', 'final_project');
		$sql = "insert into newcars values('','{$name}','miraj','{$price}','{$pic}','Active')";;

		if (mysqli_query($con, $sql)) {
			return true;
		}else {
			return false;
		}
	}

	function getAllcars() {
		$con = getConnection('localhost', 'root', '', 'final_project');
		$sql = "select * from newcars";
		$result = mysqli_query($con, $sql);
		return $result;
	}


?>