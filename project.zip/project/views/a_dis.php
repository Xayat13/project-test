<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/service.css">
</head>
<body>
	<table width=100% cellspacing="0" bgcolor="E0DDAA">



<table>
    <tr>


    <td>
         <td>
        <label><p style=font-size:60px><div1>Add Car Description</div1></p> <br> <textarea cols="60" row="50" name="mes"></textarea></label><br>

        </td>
    </td>             
    </tr>

    <tr>
    <center><p style=font-size:60px><div1>Add Car Photos</div1></p></center>
    <br><br>
    <input type="file" id="myfile" name="myfile" multiple><br><br>
   
    </tr>
</table>
    </center>
    <br><br>
    <center> <input type="submit" name="bsubmit" value="Submit" style="height:50px; width:100px"> </center>

    
</form>
	</table>
</body>
</html>