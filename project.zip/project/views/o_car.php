<script type="text/javascript" src="../assets/ajax.js"></script>
<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">
</head>
<body>
	<table width=100% cellspacing="0" bgcolor="E0DDAA">
		<tr height="50px">
			<td bgcolor="" align="center">
				<b><a href="../views/homepage.php" style="text-decoration: none; font-size: 30px; font-family: calibri; color: darkred;">CarLagbe.com</a></b>
			</td>
			<td bgcolor="141E27"></td>
			<td align="right">
					<a href="../views/profile_Admin.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Profile</b></a> |
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<img src="../assets/1.jpg" alt="Car Image" width=100% height="460">
			</td>
		</tr>
		<tr height="611px" bgcolor="203239">
			<td width="270px" valign="Top">
				
			</td>
			<td bgcolor="141E27">

			<ul>
                        
                        <li><a href="product.php">Product</a></li>
                        <li><a href="used_car.php">Used Car</a></li>
                        <li><a href="new_car.php">Add Car</a></li>
                        <li><a href="customer_service.php">Customer Service</a></li>                      
                        <li><form method="POST" action="../controllers/logout.php">
            		<input type="submit" name="b_logout" value="Logout" style="height:60px; width:100px"  >
        			</form>
                </li>
                        </ul>

                        <center>
                        <table> 



                    <tr>  




                          <td>   <div1>Color</div1></td>

                          <td

                          ><textarea cols="60" row="50" name="mes"></textarea>

                        </td>

                      </tr>





                    <tr>
                          <td>
                              <div1>Other Parts</div1>
                          </td>
                    <td>
                    <textarea cols="60" row="50" name="mes"></textarea>
                    </td>
                    
                    </tr>                    
                    
                    <tr>
                        <td>
                            <center>
                            <input type="submit" name="submit" value="Submit" style="font-size: 20px;">
                            </center>
                        </td>
                    </tr>
                    </table>
                        </center>
              
					
<br>
<br>				
			</td>
			<td  width="270px" valign="Top">
				
			</td>
		</tr>
		<tr height="40px">
			<td bgcolor="" align="left">
				<a href="../views/homepage.php" style="text-decoration: none;"><b style="font-size: 20px; font-family: calibri; color: darkred;">CarLagbe.com</b></a>
			</td>
			<td bgcolor="" align="center">
				<b style="font-size: 15px; font-family: calibri;">Copyright</b>
			</td>
			<td align="right">
					|<a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/aboutUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">About Us</b></a> |
					<a href="../views/contactUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Contact Us</b></a> |
			</td>
		</tr>
</table>
</body>
</html>