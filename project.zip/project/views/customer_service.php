<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">
	<link rel="stylesheet" href="../css/service.css">
</head>
<body>
	<table width=100% cellspacing="0" bgcolor="E0DDAA">
		<tr height="50px">
			<td bgcolor="" align="center">
				<b><a href="../views/homepage.php" style="text-decoration: none; font-size: 30px; font-family: calibri; color: darkred;">CarLagbe.com</a></b>
			</td>
			<td bgcolor="141E27"></td>
			<td align="right">
					| <a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/registration.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Registration</b></a> |
					<a href="../controllers/profileCheck.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Profile</b></a> |
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<img src="../assets/1.jpg" alt="Car Image" width=100% height="460">
			</td>
		</tr>
		<tr height="611px" bgcolor="203239">
			<td width="270px" valign="Top">
				
			</td>
			<td bgcolor="141E27">

                         <ul>
                        
                        <li><a href="product.php">Product</a></li>
                        <li><a href="used_car.php">Used Car</a></li>
                        <li><a href="new_car.php">Add Car</a></li>
                        <li><a href="customer_service.php">Customer Service</a></li>
                        <li><form method="POST" action="../controllers/logout.php">
            		<input type="submit" name="b_logout" value="Logout" style="height:60px; width:100px"  >
        			</form>
                </li>
                        </ul>		


    <center>
		 <div1>Customer Service </div1>
<table>
	<tr>
		<td>
		<div class="card">
		
		<div class="container">
			<div2><b>Car Selling</b></div2>
			<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
			<a href="#" class="button">Read More</a>
		</div>
		</div>
		</td>


		<td><div class="card">
	
		<div class="container">
		<div2><b>Parts Repair</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div></td>

		<td><div class="card">
		
		<div class="container">
		<div2><b>Car insurance</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button"><u>Read More</u></a>
		</div>
		</div></td>
	</tr>

	<tr>
		<td><div class="card">
	
		<div class="container">
		<div2><b>Battery Replacement</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div></td>

		<td><div class="card">
	
		<div class="container">
		<div2><b>Oil Change</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div>
	</td>

	<td><div class="card">
		<div class="container">
		<div2><b>24/7 Support</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div></td>
	</tr>
</table>


			</td>
			<td  width="270px" valign="Top">
				
			</td>
		</tr>
		<tr height="40px">
			<td bgcolor="" align="left">
				<a href="../views/homepage.php" style="text-decoration: none;"><b style="font-size: 20px; font-family: calibri; color: darkred;">CarLagbe.com</b></a>
			</td>
			<td bgcolor="" align="center">
				<b style="font-size: 15px; font-family: calibri;">Copyright</b>
			</td>
			<td align="right">
					|<a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/aboutUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">About Us</b></a> |
					<a href="../views/contactUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Contact Us</b></a> |
			</td>
		</tr>
	</table>
</body>
</html>