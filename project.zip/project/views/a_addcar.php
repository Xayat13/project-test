<script type="text/javascript" src="../assets/S.js"></script>
<html>
<head>
	<title>CarLagbe Login</title>
	<link rel="stylesheet" href="../css/index.css">
</head>
<body> 
<form method="POST" action="../controllers/addcarCheck.php" enctype="multipart/form-data" onsubmit="return reg()">
	<table width=100% cellspacing="0" bgcolor="#3aafa9">
						<tr align="center">
							<td colspan="2">
								<b style="font-size: 35px; font-family: calibri; color: white;">Add Car<br> <hr></b>
							</td>
						</tr>
						<tr align="center">
							<td>
								<b style="font-size: 25px; font-family: calibri; color: white;">Name :</b>
							</td>
							<td><input id="name" type="text" name="name"></td><td id="nameError"></td>
								
							
						</tr>
						
						<tr align="center">
							<td>
								<b style="font-size: 25px; font-family: calibri; color: white;">Price :</b>
							</td>
							<td><input id="pirce" type="text" name="price"></td><td id="priceError"></td>
						</tr>
										
						
						<tr>
							<td>
								<b style="font-size: 25px; font-family: calibri; color: white;">Car Picture :</b>
							</td>
							<td align="right"><input id ="pic " type="file" name="pic" style="color: white;" ></td><td id="picError"></td>
						</tr>
						
							
						
						<tr align="center">
							<td colspan="2">
								<br><input type="submit" name="submit" value="Submit" style="font-size: 20px;">  <br><hr>
							</td>
						</tr>
					</table>
				</form>
	</table>
</body>
</html>