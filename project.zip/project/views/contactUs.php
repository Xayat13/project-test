<html>
<head>
	<title>CarLagbe Login</title>
	<link rel="stylesheet" href="../css/contactus.css">
</head>
<body>
	<table width=100% cellspacing="0" bgcolor="E0DDAA">
		<tr height="50px">
			<td bgcolor="" align="center">
				<b><a href="../views/homepage.php" style="text-decoration: none; font-size: 30px; font-family: calibri; color: darkred;">CarLagbe.com</a></b>
			</td>
			<td bgcolor="141E27"></td>
			<td align="right">
					<a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/registration.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Registration</b></a> |
					<a href="../views/profile.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Profile</b></a> |
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<img src="../assets/3.jpg" alt="Car Image" width=100% height="460">
			</td>
		</tr>
		<tr height="411px" bgcolor="203239">
			<td width="270px" valign="Top">
				
			</td>
			<td bgcolor="141E27" align="center">
				 <div>Contact US </div>

	<div1>
        <br>Address:
		<br>Narayanganj
		<br>Bhuigor
		    
</div1>
<br><br><br>
	<div1>


	  <br>Phone Number 
	  <br>015377517260
</div1>

<P><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14615.116171473795!2d90.4823181!3d23.6838585!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6afb226f1f8e2a09!2sRaghunathpur%20Hadisa%20Car%20Hat!5e0!3m2!1sen!2sbd!4v1649953276379!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></P>

			</td>
			<td  width="270px">
			</td>
		</tr>
		<tr height="200px" bgcolor="203239">
			<td></td>
			<td bgcolor="141E27"></td>
			<td></td>
		</tr>
		<tr height="40px">
			<td bgcolor="" align="left">
				<a href="../views/homepage.php" style="text-decoration: none;"><b style="font-size: 20px; font-family: calibri; color: darkred;">CarLagbe.com</b></a>
			</td>
			<td bgcolor="" align="center">
				<b style="font-size: 15px; font-family: calibri;">Copyright</b>
			</td>
			<td align="right">
					|<a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/aboutUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">About Us</b></a> |
					<a href="../views/contactUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Contact Us</b></a> |
			</td>
		</tr>
	</table>
</body>
</html>