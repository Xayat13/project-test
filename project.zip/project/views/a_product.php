<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">
<center><div1>Available Product</div1></center>

<br>
<br>
<table width="100%">
<tr>


<td height="100%">

        <div class="card" >
            <img src="../assets/04.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>BMW</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>

    <td> 

        <div class="card" >
            <img src="../assets/05.png" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>BMW</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a>  
                </div>
        </div>
          
    </td>


    <td height="100%">

        <div class="card" >
            <img src="../assets/06.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>BMW</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a>  
                </div>
        </div>

    </td>

</tr>

<tr>

<td height="100%">
        <div class="card" >
            <img src="../assets/01.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>BMW</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>

    <td>

        <div class="card" >
            <img src="../assets/02.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>BMW</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>


    <td height="100%">

        <div class="card" >
            <img src="../assets/03.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center><h4><b>BMW</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>
    </td>


</tr>

</table>
</body>
</html>