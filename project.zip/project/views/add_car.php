<script type="text/javascript" src="../assets/S.js"></script>
<html>
<head>
	<title>CarLagbe Login</title>
</head>
<body>
	<table width=100% cellspacing="0" bgcolor="E0DDAA">
		<tr height="50px">
			<td bgcolor="" align="center">
				<b><a href="../views/homepage.php" style="text-decoration: none; font-size: 30px; font-family: calibri; color: darkred;">CarLagbe.com</a></b>
			</td>
			<td bgcolor="141E27"></td>
			<td align="right">
					| <a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/registration.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Registration</b></a> |
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<img src="../assets/5.jpg" alt="Car Image" width=100% height="460">
			</td>
		</tr>
		<tr height="411px" bgcolor="203239">
			<td width="270px" valign="Top">
				
			</td>
			<td bgcolor="141E27" align="center">
				<form method="POST" action="../controllers/addcarCheck.php" enctype="multipart/form-data" onsubmit="return reg()">
					<table width="500">
						<tr align="center">
							<td colspan="2">
								<b style="font-size: 35px; font-family: calibri; color: white;">Add Car<br> <hr></b>
							</td>
						</tr>
						<tr align="center">
							<td>
								<b style="font-size: 25px; font-family: calibri; color: white;">Name :</b>
							</td>
							<td><input id="name" type="text" name="name"></td><td id="nameError"></td>
								
							
						</tr>
						
						<tr align="center">
							<td>
								<b style="font-size: 25px; font-family: calibri; color: white;">Price :</b>
							</td>
							<td><input id="pirce" type="text" name="price"></td><td id="priceError"></td>
						</tr>
										
						
						<tr>
							<td>
								<b style="font-size: 25px; font-family: calibri; color: white;">Car Picture :</b>
							</td>
							<td align="right"><input id ="pic " type="file" name="pic" style="color: white;" ></td><td id="picError"></td>
						</tr>
						
							
						
						<tr align="center">
							<td colspan="2">
								<br><input type="submit" name="submit" value="Submit" style="font-size: 20px;">  <br><hr>
							</td>
						</tr>
					</table>
				</form>
			</td>
			<td  width="270px">
			</td>
		</tr>
		<tr height="200px" bgcolor="203239">
			<td></td>
			<td bgcolor="141E27"></td>
			<td></td>
		</tr>
		<tr height="40px">
			<td bgcolor="" align="left">
				<a href="../views/homepage.php" style="text-decoration: none;"><b style="font-size: 20px; font-family: calibri; color: darkred;">CarLagbe.com</b></a>
			</td>
			<td bgcolor="" align="center">
				<b style="font-size: 15px; font-family: calibri;">Copyright</b>
			</td>
			<td align="right">
					| <a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/aboutUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">About Us</b></a> |
					<a href="../views/contactUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Contact Us</b></a> |
			</td>
		</tr>
	</table>
</body>
</html>