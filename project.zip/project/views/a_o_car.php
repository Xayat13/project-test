<script type="text/javascript" src="../assets/ajax.js"></script>
<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">
</head>
<body>
	<table width=100% cellspacing="0" bgcolor="E0DDAA">

                        <center>
                        <table> 



                    <tr>  




                          <td>   <div1>Color</div1></td>

                          <td

                          ><textarea cols="60" row="50" name="mes"></textarea>

                        </td>

                      </tr>





                    <tr>
                          <td>
                              <div1>Other Parts</div1>
                          </td>
                    <td>
                    <textarea cols="60" row="50" name="mes"></textarea>
                    </td>
                    
                    </tr>                    
                    
                    <tr>
                        <td>
                            <center>
                            <input type="submit" name="submit" value="Submit" style="font-size: 20px;">
                            </center>
                        </td>
                    </tr>
                    </table>
                        </center>
              
					

</table>
</body>
</html>