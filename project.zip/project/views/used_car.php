<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">
</head>
<body>
	<table width=100% cellspacing="0" bgcolor="E0DDAA">
		<tr height="50px">
			<td bgcolor="" align="center">
				<b><a href="../views/homepage.php" style="text-decoration: none; font-size: 30px; font-family: calibri; color: darkred;">CarLagbe.com</a></b>
			</td>
			<td bgcolor="141E27"></td>
			<td align="right">
					| <a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/registration.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Registration</b></a> |
					<a href="../controllers/profileCheck.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Profile</b></a> |
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<img src="../assets/1.jpg" alt="Car Image" width=100% height="460">
			</td>
		</tr>
		<tr height="611px" bgcolor="203239">
			<td width="270px" valign="Top">
				
			</td>
			<td bgcolor="141E27">

                         <ul>
                        
                        <li><a href="product.php">Product</a></li>
                        <li><a href="used_car.php">Used Car</a></li>
                        <li><a href="new_car.php">Add Car</a></li>
                        <li><a href="customer_service.php">Customer Service</a></li>
                        <li><form method="POST" action="../controllers/logout.php">
            		<input type="submit" name="b_logout" value="Logout" style="height:60px; width:100px"  >
        			</form>
                </li>
                        </ul>
<br>
<br>				


<center><div1>Used Car</div1>  </p4></center>

<br>
<br>
<table width="100%">
<tr>


<td height="100%">

        <div class="card" >
            <img src="../assets/001.jpg" alt="peojuct" style="width:100%" >
                <div class="container">
                   <center> <h4><b>BMW</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>

    <td> 

        <div class="card" >
            <img src="../assets/002.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Audi</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a>  
                </div>
        </div>
      
    </td>


    <td height="100%">
   
        <div class="card" >
            <img src="../assets/001.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Toyota</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a>   
                </div>
        </div>

    </td>

</tr>

<tr>

<td height="100%">

        <div class="card" >
            <img src="../assets/008.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Mercedes</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a>  
                </div>
        </div>

    </td>

    <td>

        <div class="card" >
            <img src="../assets/001.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Aston Martine</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a>   
                </div>
        </div>

    </td>


    <td height="100%">

        <div class="card" >
            <img src="../assets/008.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center><h4><b>mazda</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a>   
                </div>
        </div>
    </td>


</tr>

</table>
<br>
			</td>
			<td  width="270px" valign="Top">
				
			</td>
		</tr>
		<tr height="40px">
			<td bgcolor="" align="left">
				<a href="../views/homepage.php" style="text-decoration: none;"><b style="font-size: 20px; font-family: calibri; color: darkred;">CarLagbe.com</b></a>
			</td>
			<td bgcolor="" align="center">
				<b style="font-size: 15px; font-family: calibri;">Copyright</b>
			</td>
			<td align="right">
					|<a href="../views/login.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Login</b></a> |
					<a href="../views/aboutUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">About Us</b></a> |
					<a href="../views/contactUs.php" style="text-decoration: none; color: darkred;"><b style="font-size: 20px; font-family: calibri;">Contact Us</b></a> |
			</td>
		</tr>
	</table>
</body>
</html>