<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">

<center><div1>Used Car</div1>  </p4></center>
<table width="100%">
<tr>


<td height="100%">

        <div class="card" >
            <img src="../assets/001.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Bmw</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>

    <td> 
        <div class="card" >
            <img src="../assets/002.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Audi</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>
    
    </td>


    <td height="100%">

        <div class="card" >
            <img src="../assets/008.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Toyota</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>

</tr>

<tr>

<td height="100%">

        <div class="card" >
            <img src="../assets/001.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Mercedes</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>

    <td>
 
        <div class="card" >
            <img src="../assets/002.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center> <h4><b>Aston Martine</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>

    </td>


    <td height="100%">
 
        <div class="card" >
            <img src="../assets/008.jpg" alt="peojuct" style="width:100%">
                <div class="container">
                   <center><h4><b>Mazda</b></h4></center>
                   <a href="../views/o_car.php"><center><p>Order Now</p> </center></a> 
                </div>
        </div>
    </td>


</tr>

</table>
</body>
</html>