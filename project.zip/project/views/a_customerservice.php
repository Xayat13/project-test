<!DOCTYPE html>
<html>
<head>
	<title>CarLagbe Homepage</title>
	<link rel="stylesheet" href="../css/index.css">
	<link rel="stylesheet" href="../css/service.css">
</head>
<body><table>

    <center>
		 <div1>Customer Service </div1>
<table>
	<tr>
		<td>
		<div class="card">
		
		<div class="container">
			<div2><b>Car Selling</b></div2>
			<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
			<a href="#" class="button">Read More</a>
		</div>
		</div>
		</td>


		<td><div class="card">
	
		<div class="container">
		<div2><b>Parts Repair</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div></td>

		<td><div class="card">
		
		<div class="container">
		<div2><b>Car insurance</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button"><u>Read More</u></a>
		</div>
		</div></td>
	</tr>

	<tr>
		<td><div class="card">
	
		<div class="container">
		<div2><b>Battery Replacement</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div></td>

		<td><div class="card">
	
		<div class="container">
		<div2><b>Oil Change</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div>
	</td>

	<td><div class="card">
		<div class="container">
		<div2><b>24/7 Support</b></div2>
		<p style = "Color: white ;"><b>Lorem,ipsum Dolor sit Amet COnsectertur Adipisicing Elit. Corporis, NISI</b></p> 
		<a href="#" class="button">Read More</a>
		</div>
		</div></td>
	</tr>
</table>
	</table>
</body>
</html>